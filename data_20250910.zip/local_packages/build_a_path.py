# returns an OS dependent path from a dictionary keyword formed as a / separated
# path (e.g. dict['path']='flaskapp/static/products') relative to the current local
# directory

import os

def build_path(dict,key):
    #p=os.getcwd()
    p=''
    s=tuple(map(str, str(dict[key]).split('/')))
    for each in s:
        p=os.path.join(p,each)
    return(p)


    
    