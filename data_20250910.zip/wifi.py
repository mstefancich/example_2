# -*- coding: utf-8 -*-
"""
Created on Tue Oct 30 09:11:57 2018

@author: jasper.vander.ster
"""

from subprocess import Popen, STDOUT, PIPE
import time
import os
import lxml.html
#from time import sleep

def get_wifi_networks(tries=5):
    """
    Uses command line (Linux) to get a list of all available Wi-Fi networks
    
    output
    ------
        networks: list of networks, where each network is SSID, MODE, CHAN, RATE, SIGNAL, BARS, SECURITY
    """
    
    trie = 0
    networks = []
    while not networks and trie < tries:
        handle = Popen("nmcli dev wifi", shell=True, stdout=PIPE, stderr=STDOUT, stdin=PIPE)
        while handle.poll() == None:
            output_line = handle.stdout.readline().strip()
            # Check if not empty string
            if output_line:
                ## Split output on two or more spaces
                network = [s.strip() for s in output_line.split("  ") if (s and s.strip() != "*")]
                networks.append(network)
        
        # First line is SSID MODE CHAN RATE SIGNAL BARS SECURITY, we don't need it so we pop it
        networks.pop(0)
        trie += 1
        time.sleep(0.5)
    
    unique_ssids = []
    unique_networks = []
    for network in networks:
        if network[0] not in unique_ssids:
            unique_networks.append(network)
            unique_ssids.append(network[0])
    
    return unique_networks
   
def enable_wifi():
    """
    Enables Wi-Fi using the command line (Linux)
    """
    handle = Popen("nmcli radio wifi on", shell=True, stdout=PIPE, stderr=STDOUT, stdin=PIPE)
    while handle.poll() == None:
        print(handle.stdout.readline().strip())
    pass
    
def disable_wifi():
    """
    Disables Wi-Fi using the command line (Linux)
    """
    handle = Popen("nmcli radio wifi off", shell=True, stdout=PIPE, stderr=STDOUT, stdin=PIPE)
    while handle.poll() == None:
        print(handle.stdout.readline().strip())
    pass

def disconnect_wifi(network_ssid):
    """
    Disconnects from a Wi-Fi network
    """
    handle = Popen("nmcli con down %s" % network_ssid, shell=True, stdout=PIPE, stderr=STDOUT, stdin=PIPE)
    while handle.poll() == None:
        print(handle.stdout.readline().strip())
    pass

def connect_wifi(network_ssid, network_security, password=""):
    """
    Uses command line to connect to a Wi-Fi network
    """
    if network_security == "--":
        handle = Popen("nmcli dev wifi connect %s" % (network_ssid), shell=True, stdout=PIPE, stderr=STDOUT, stdin=PIPE)
    else:
        handle = Popen("nmcli dev wifi connect %s password %s" % (network_ssid, password), shell=True, stdout=PIPE, stderr=STDOUT, stdin=PIPE)
    while handle.poll() == None:
        print(handle.stdout.readline().strip())
    pass

def disable_ethernet():
    """
    Disables Ethernet connection
    """
    handle = Popen("sudo ip link set eth0 down", shell=True, stdout=PIPE, stderr=STDOUT, stdin=PIPE)
    while handle.poll() == None:
        print(handle.stdout.readline().strip())
    pass

def enable_ethernet():
    """
    Enables Ethernet connection
    """
    handle = Popen("sudo ip link set eth0 up", shell=True, stdout=PIPE, stderr=STDOUT, stdin=PIPE)
    while handle.poll() == None:
        print(handle.stdout.readline().strip())
    pass

def check_connection(hostnames = ["www.google.com"]):
    """
    Checks pinging CGI.com to check the connection. Needs a good connection
    """
    response = [os.system("ping -c 1 %s" % hostname) for hostname in hostnames]
    return sum(response) < (len(hostnames) / 4.0)

def get_login_form(site="http://www.google.com"):
    """
    If connected to a wifi source, but not able to connect to google.com, there's probably a login form .
    Returns the form that is most likely to be the user login form
    
    input
    -----
        site: site to check the login (if not connected to world wide web, every website will probably redirect you to (guest) network login page)
        
    output
    ------
        form: lxml.EtreeElement or None (when 0 or more than 2 forms are found)
    """
    ## TODO STACKOVERFLOW IS JUST FOR TESTING PURPOSES (TODO: Change site to google.com)
    handle = Popen("curl -L %s > login.html" % (site), shell=True, stdout=PIPE, stderr=STDOUT, stdin=PIPE)
    while handle.poll() == None:
        outline = handle.stdout.readline().strip()
        if outline:
            print(outline)

    html_login = lxml.html.parse("login.html")
    forms = list(html_login.iter("form"))
    if len(forms) < 1:
        print("No login form found")
        return None
    if len(forms) == 1:
        return forms[0]
    possible_login_forms = []
    for form in forms:
        if form.method.upper() == "POST":
            possible_login_forms.append(form)
    if len(possible_login_forms) == 1:
        return possible_login_forms[0]
    print("More than 1 form found, can't identify login form")
    return possible_login_forms

def get_user_inputs(form):
    """
    Analyzes a form to analyze the input fields and returns the fields most likely to need user interaction
    
    input
    -----
        form: lxml.html.FormElement
    
    output
    ------
        inputs: list of inputs elements that require user input
    """
    user_inputs = []
    for form_input in form.inputs:
        try:
            if form_input.type not in ["hidden", "submit", "button"] and "openid" not in form_input.name:
                user_inputs.append(form_input)
        except TypeError:
            pass
    return user_inputs

def get_url_from_html(html_file):
    html_data = lxml.html.parse(html_file)
    url = html_data.xpath(".//meta[@itemprop='name']/@content")
    return url

def get_action_url(url, form):
    if "://" in form.action:
        return form.action
    return "%s%s" % (url, form.action)

def login(url, user_data):
    """
    Takes user input to login to website
    
    input
    -----
        url: url to login to
        user_input: nested list of [[user_input, data]]
    
    output
    ------
        login_succesful: boolean
    """
    data = "&".join(["=".join([inp_name, d]) for (inp_name, d) in user_data])
    
    handle = Popen('curl -d "%s" %s' % (data, url), shell=True, stdout=PIPE, stderr=STDOUT, stdin=PIPE)
    while handle.poll() == None:
        outline = handle.stdout.readline().strip()
        if outline:
            print(outline)
    
    login_succesful = check_connection()
    return login_succesful
    
    
    