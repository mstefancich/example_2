# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.9] - 2018-12-12
### Added
- Language support framework
- English language support
- Dutch language support
- Start menu with selection of the two applications
- Start menu to choose a language
- TCPreplay as a dependency

### Changed
- Merged capturer with receiver application
- Spilt code from kv language file

### Removed
- Code regarding the PCAP send mechanism (unused)
- demo_gui.py since it's merged now

### Fixed
- Bug at the test screen regarding minutes and hour capture format

### Deprecated
- SD card for storage of pcap capture

## [0.8.2] - 2018-12-03
### Added
- RTC Clock to keep track of time
- Basic version of logging
- Notice of packets/s after test capture
- S7COMM support in OT protocol selection

### Fixed
- Bug where "Finished" was not displaying at CaptureScreen

### Deprecated
- SD card for storage of pcap capture


## [0.8.1] - 2018-11-20
### Added
- Version notice in main screen

### Fixed
- Bug where the app stops when there is no data found


## [0.8.0] - 2018-11-10
### Added
- GUI to provide interaction with the application
- Capture functionality using tcpdump
- Capture duration configuration at the start screen
- Load application on boot
- Reminder to insert USB when no USB inserted
- Test capture analysis using Scapy
- Changelog to keep track of changes
- CIP, modbus, modbus, EtherCAT, Hart, OPC UA support in OT protocol selection
