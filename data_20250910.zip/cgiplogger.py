# -*- coding: utf-8 -*-
"""
Created on Wed Oct 10 08:27:33 2018

@author: jasper.vander.ster
"""

#IMPORTANT: Run script as SU
import subprocess
from datetime import datetime # Used the genreate the filename
import os
from threading import Timer
import psutil

import logging

## Logger support
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
    
# create a file handler
handler = logging.FileHandler('cgip_logger.log')
handler.setLevel(logging.DEBUG)

# create a logging format
formatter = logging.Formatter('[%(asctime)s - %(name)s] : %(levelname)s - %(message)s')
handler.setFormatter(formatter)

# add the handlers to the logger
logger.addHandler(handler)


def start_capture(duration_hours, local_time):
    """
    Starts the capture process using subprocess
    
    input
    -----
        duration_hours: integer for duration in hours
        
    output
    ------
        tcpdump_process: process to call .poll() on to check status -- None means running, 0 finished
        file: filename including directory
    """
    usb_directory = get_usb_directory()
    default_directory = "/home/pi/cgip_logger"
    
    #Check if the default directory exists and if not, create the default directory
    if not os.path.exists(default_directory):
        os.makedirs(default_directory)
        
    
    duration_seconds = 60*60*duration_hours #Get duration in seconds
    

    if usb_directory:
        filename = get_filename(local_time, usb_directory)
        file = os.path.join(usb_directory, filename)
    else:
        filename = get_filename(local_time, default_directory)
        file = os.path.join(default_directory, filename)

    print(file)
    tcpdump_process = capture(file)
    #Scedule end of capture
    Timer(duration_seconds, end_capture, [tcpdump_process]).start()
    
    #Check if process is running correctly
    if tcpdump_process.poll() is None:
        print("Succesfully started capturing data to %s" % file)
        logger.info("Succesfully started capturing data to %s" % file)
    return (tcpdump_process, file)

def kill(proc_pid):
    """
    Kill the process by id, including all the children processes
    
    input
    -----
        proc_pid: id of process that needs to be killed
    """
    process = psutil.Process(proc_pid)
    for proc in process.children(recursive=True):
        proc.kill()
    process.kill()

def capture(file):
    """
    Initiate the capture process using subprocess
    
    input
    -----
        file: filepath used to save the capture
        
    output
    ------
        tcpdump_process: process used by tcpdump
    """
    # stdout=subprocess.PIPE, shell=True
    tcpdump_process = subprocess.Popen(["sudo", "tcpdump", "-U", "-w", file, "-i", "eth0", "-C", str(1000)], stdout=None, stdin=None, stderr=None, close_fds=True,)
    logger.debug("Process started with command: sudo tcpdump -U -w %s -i eth0 - C %s" % (file, str(1000)))
    print(tcpdump_process.pid)
    return tcpdump_process

def end_capture(tcpdump_process):
    """
    Ends the capture process using terminate
    
    input
    -----
        tcpdump_process: process that needs to be terminated
        
    output
    ------
        Boolean: wether or not the termination is succesfull (None is still running, 0/1 is succesfull)
    """
    print("End capture from cgiplogger.py")
    try:
        kill(tcpdump_process.pid)
        print("Succesfully ended capture!")
        print(type(tcpdump_process.poll()))
    except psutil.NoSuchProcess:
        print("Process already killed")
    return tcpdump_process.poll()

def get_usb_directory():
    """
    Gets a usb directory
    
    input
    -----
        
    output
    ------
        usb_directory: path to usb directory or None when not found
    """
    rpi_str = "ls /media/pi"
    proc = subprocess.Popen(rpi_str, shell=True, preexec_fn=os.setsid, stdout=subprocess.PIPE)
    line = proc.stdout.readline().strip()
    if line:
        print("USB device %s connected" % line)
        usb_directory =  os.path.join("/media/pi", line)
        return usb_directory
    return None

def get_filename(local_time, directory):
    """
    Gets a filename based on date
    
    input
    -----
        
    output
    ------
        filename: filename including date details
    """
    filename = "%s_capture.pcap" % (local_time)
    print(filename)
    new_filename = not os.path.isfile(os.path.join(directory, filename))
    print(new_filename)
    i = 1
    while not new_filename:
        filename = "%s_capture%s.pcap" % (local_time, i)
        new_filename = not os.path.isfile(os.path.join(directory, filename))
        i += 1
    return filename


## Use tcpdump_process.terminate() when trying to kill it in GUI

