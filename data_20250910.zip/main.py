# -*- coding: utf-8 -*-
"""
Created on Fri Oct 12 08:56:56 2018

@author: jasper.vander.ster
"""
from kivy.app import App
from kivy.lang import Builder, Observable
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.progressbar import ProgressBar
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.textinput import TextInput
from kivy.uix.slider import Slider
from kivy.core.window import Window
from kivy.properties import NumericProperty, StringProperty, BooleanProperty, ObjectProperty

from kivy.clock import Clock
from functools import partial

from subprocess import Popen, STDOUT, PIPE
import psutil
import os
import threading
import scapy.all as scapy
import time
import logging

import cgiplogger as cgip_logger
import pcap_analysis
import wifi
import gettext


def _(string):
    '''This is just so we can use the default gettext format'''
    return string

VERSION = _("0.9") # major.minor.build[.revision]

#Builder.load_string("""
#
#""")

class CGIInfoLabel(Label):
    source_text = StringProperty('')
    
class CGISmallButton(Button):
    pass

class WarningFileSizePopup(Popup):
    pass

class CGITitle(Label):
    source_text = StringProperty('')

class CGIQuitTitle(Button):
    pass

class LoadFilePopup(Popup):
    pass

# Declare both screens
class StartScreen(Screen):
    
    def check(self):
        """
        Check the usb connected/size and if not enough, it will popup a warning
        """
        msg = self.check_usb_space()
        if msg is True:
            logger.info("USB device connected")
            self.switch_to_test()
        else:
            logger.info("No USB device connected")
            self.popup = WarningFileSizePopup()
            self.popup.ids.warninginfolabel.text = msg
            self.popup.open()
            
    def close_and_continue(self):
        """
        Close the popup and continue
        """
        logger.info("Dismissed message USB device")
        msg = self.check_usb_space()
        if msg is True:
            logger.info("USB device connected")
        else:
            logger.info("No USB device connected")
        self.popup.dismiss()
        self.switch_to_test()
    
    def switch_to_test(self):
        """
        Switch the window to the test screen (used in popup)
        """
        logger.debug("Test screen activated")
        self.manager.transition.direction = 'up'
        self.manager.current = 'test'
        self.test_duration_minutes = float(self.ids.test_duration.value)
        self.capture_duration_minutes = float(self.ids.capture_duration.value)
        App.get_running_app().start_test_capture()
    
    def check_usb_space(self):
        """
        Checks the usb space left and updates the message accordingly
        """
        usb_dir = cgip_logger.get_usb_directory()
        default_dir = "/home/pi/cgip_logger/"
        if usb_dir:
            if int(self.get_storage_left(usb_dir)) > 40*1024*1024*1024:
                # Everything optimal, usb inserted, size > 40 GB
                return True
            else:
                # Need more storage on usb, please remove or continue if you know what you're doing
                msg = _("You have %s of free space left on your USB device.\nWe advice 40GB of free space.") % pcap_analysis.print_file_size(self.get_storage_left(usb_dir))
        else:
            msg = _("Please consider using a USB storage device.\nThe internal SD card has %s free space left.") % pcap_analysis.print_file_size(self.get_storage_left(default_dir))
        return msg
    
    def get_storage_left(self, directory):
        """
        Returns available file size for directory (excluding su allocated space)
        """
        s = os.statvfs(directory)
        logger.debug("Space left at capture destination directory: %s" % pcap_analysis.print_file_size(s.f_bsize * s.f_bavail))
        return s.f_bsize * s.f_bavail


class TestScreen(Screen):
    
    def start_capture_progress(self, tcpdump_process, duration_mins=5, estimate_duration=6, filename="/home/pi/cgip_logger/test.pcap"):
        """
        Tracks test capture progress, as specified by input variables
        Starts progress bar and eta updates as well
        """
        # Make sure eth0 port is open for capture
        wifi.enable_ethernet()
        logger.info("Ethernet enabled")
        
        self.duration_mins = duration_mins
        self.estimate_duration = estimate_duration
        self.tcpdump_process = tcpdump_process
        self.filename = filename
        self.update_progressbar = True
        self.ids.progress.value = 0
        
        self.ids.continuebutton.disabled = True
        print("Estimated duration: %s" % estimate_duration)
        
        self.percent_update = 1./estimate_duration
        
        self.ids.eta.text = "ETA: %.1f min" % (float(estimate_duration))
        
        self.ids.status_update.text = _("Capturing test data...")
        
        Clock.schedule_interval(partial(self.update_capture_progress, self.percent_update), 1./30)
        Clock.schedule_interval(self.update_eta, 6)
        Clock.schedule_interval(self.check_finished, 3)
        return  
        
    def update_capture_progress(self, percent_update, dt):
        """
        Stop is built-in to ensure stopping when wanting an unschedule
        """
        self.ids.progress.value += percent_update*dt
        return self.update_progressbar

    def update_eta(self, dt):
        """
        Updates the eta time, hardcoded (so not depending on actual performance)
        """
        ## "ETA: 7 min" --> int(7)
        old_eta = float(self.ids.eta.text.split(" ")[1])
        print(dt, old_eta)
        self.ids.eta.text = "ETA: %.1f min" % (max(old_eta - dt/60., 0))
        if not self.update_progressbar:
            self.ids.eta.text = _("Finished!")
            return False
    
    def stop_capture_progress(self):
        """
        Stops the capture process, including the visual progress identifiers
        """
        logger.info("Stopping test capture process manually")
        Clock.unschedule(partial(self.update_capture_progress, self.percent_update))
        self.update_progressbar = False
        Clock.unschedule(self.update_eta)
        Clock.unschedule(self.check_finished)
        
        #self.tcpdump_process.terminate() needs root priviliges:
        print("Handmatig uitzetten")
        print(self.tcpdump_process.pid)
        
        ## TODO Fix kill of process, currently not working
        try:
            cgip_logger.kill(self.tcpdump_process.pid)
            print("Succesfully ended capture!")
            logger.info("Succesfully ended test capture process")
            print(type(self.tcpdump_process.poll()))
        except psutil.NoSuchProcess:
            print("Process already killed")
            logger.info("Process has already been killed")
        
        self.ids.progress.value = 0
        self.ids.eta.value = _("Terminated")
        self.clean_test_files()
        logger.info("Test files cleaned")
        
    def check_finished(self, dt):
        """
        Checks if tcpdump_process is finished (is not None)
        Returns False when finished, True while running
        """
        print(type(self.tcpdump_process.poll()))
        if self.tcpdump_process.poll() is not None:
            logger.info("Finished capturing")
            self.ids.status_update.text = _("Analyzing test data...")
            t = threading.Thread(target=self.analyse_pcap, args = ())
            t.start()
            return False
        return True
    
    def analyse_pcap(self):
        """
        Analyse the first pcap file captured by the test capture
        Updates the status_update label as well and unschedules any scheduled function
        """
        logger.info("Analyzing Test PCAP file")
        print(self.filename)
        self.local_time = time.strftime('%Y%m%d_%H%M')
        try:
            ot_data, packets_per_second = pcap_analysis.analyse_pcap(self.filename)
        except scapy.Scapy_Exception:
            # No data found, so only update text and not the rest (button, cleaning, etc)
            logger.info("No data found at all")
            ot_data = -1
        
        if ot_data < 0:
            self.ids.status_update.text = _("There's no traffic found.\nMake sure you configure your switch correctly.\nMake sure the ethernet cable is connected.\nFor any further questions, please see the manual.")
            Clock.unschedule(self.update_capture_progress)
            Clock.unschedule(self.update_eta)
    
            self.ids.progress.value = 60
            self.update_progressbar = False
            self.ids.eta.text = _("Finished!")
            self.clean_test_files()
            return False
        
        ## Capture data found
        directory = os.path.dirname(self.filename)
        print(os.listdir(directory))
        
        capture_file_size = sum(os.path.getsize(os.path.join(directory, f)) for f in os.listdir(directory) if (os.path.isfile(os.path.join(directory, f)) and "test" in f))
        est_file_size = pcap_analysis.estimate_file_size(capture_file_size, self.duration_mins, self.actual_capture_duration)

        Clock.unschedule(self.update_capture_progress)
        Clock.unschedule(self.update_eta)

        self.ids.progress.value = 60
        self.update_progressbar = False
        self.ids.eta.text = _("Finished!")
        
        if int(self.actual_capture_duration) % 60 == 0:
            # Full hour
            formatted_duration = _("%s hour") % (int(self.actual_capture_duration/60)) if int(self.actual_capture_duration/60) else _("%s minute") % int(self.actual_capture_duration)
        else:
            formatted_duration = _("%s hour %s minutes") % (int(self.actual_capture_duration/60), (int(self.actual_capture_duration)%60)) if int(self.actual_capture_duration/60) else _("%s minute") % int(self.actual_capture_duration)
        if ot_data > 0.05:
            text = _("There's been %s captured (~%s packets/s).\nThis data contains ~%.1f%% OT data. Click continue to run the full capture.\nEstimated file size for the full %s capture: %s") % (pcap_analysis.print_file_size(capture_file_size), int(packets_per_second), ot_data*100, formatted_duration, pcap_analysis.print_file_size(est_file_size))
        else:
            text = _("There's been %s captured (~%s packets/s).\nThis data DOES NOT contain OT data. Click continue if you insist on running the full capture.\nEstimated file size for the full %s capture: %s") % (pcap_analysis.print_file_size(capture_file_size), int(packets_per_second), formatted_duration, pcap_analysis.print_file_size(est_file_size))
        
        logger.debug("Amount of captured data: %s" % pcap_analysis.print_file_size(capture_file_size))
        
        self.ids.status_update.text = text
        self.ids.continuebutton.disabled = False

        # Clean test files
        self.clean_test_files()
        return True
    
    def clean_test_files(self):
        """
        Clean test files in the directory of the test files
        This removes all .PCAP files in the directory
        """
        logger.info("Cleaning Test Files")
        directory = os.path.dirname(self.filename)
        
        for item in os.listdir(directory):
            if item.endswith(".pcap") and "test" in item:
                os.remove(os.path.join(directory, item))


class CaptureScreen(Screen):
    
    def start_capture_progress(self, tcpdump_process, duration_mins=120, filename="/home/pi/cgip_logger/data.pcap"):
        """
        Starts the capture progress and initializes the progress bar, ETA and status update
        """
        self.duration_mins = duration_mins
        self.tcpdump_process = tcpdump_process
        self.filename = filename
        self.update_progressbar = True
        self.ids.finishbutton.disabled = True
        self.ids.progress.value = 0
        
        #print(self.ids.process.value)
        percent_update = 1./duration_mins
        
        self.ids.eta.text = "ETA: %.1f min" % (float(duration_mins))
        
        self.ids.status_update.text = "Capturing data..."
        
        Clock.schedule_interval(partial(self.update_capture_progress, percent_update), 1./30)
        Clock.schedule_interval(self.update_eta, 6)
        Clock.schedule_interval(self.check_finished, 3)
        return
        
    def update_capture_progress(self, percent_update, dt):
        """
        Update the capture progress bar
        """
        self.ids.progress.value += percent_update*dt
        return self.update_progressbar

    def update_eta(self, dt):
        """
        Updates the eta time, hardcoded (so not dependend on actual performance)
        """
        ## "ETA: 7 min" --> int(7)
        old_eta = float(self.ids.eta.text.split(" ")[1])
        print(dt, old_eta)
        self.ids.eta.text = "ETA: %.1f min" % (max(old_eta - dt/60., 0))
        if not self.update_progressbar:
            self.ids.eta.text = _("Finished!")
            return False
    
    def stop_capture_progress(self):
        """
        Stops the capture process, including the visual progress identifiers
        """
        logger.info("Stopping capture process manually")
        Clock.unschedule(self.update_capture_progress)
        Clock.unschedule(self.update_eta)
        self.update_progressbar = False
        
        #self.tcpdump_process.terminate() needs root priviliges:
        print("Handmatig uitzetten")
        try:
            cgip_logger.kill(self.tcpdump_process.pid)
            logger.info("Succesfully ended capture process")
        except psutil._exceptions.NoSuchProcess:
            print("Already killed automatically")
            logger.info("Process has already been killed")
        self.ids.progress.value = 0
        self.ids.eta.value = _("Terminated")
        
    def check_finished(self, dt):
        """
        Checks if tcpdump_process is finished (is not None)
        Returns False when finished, True while running
        """
        print(type(self.tcpdump_process.poll()))
        if self.tcpdump_process.poll() is not None:
            logger.info("Finished capturing")
            self.ids.status_update.text = _("Done capturing data")
            self.change_pcap_names()
            directory = os.path.dirname(self.filename)
            base_filename = os.path.splitext(os.path.basename(self.filename))[0]
            capture_file_size = sum(os.path.getsize(os.path.join(directory, f)) for f in os.listdir(directory) if (os.path.isfile(os.path.join(directory, f)) and base_filename in f))
            
            Clock.unschedule(self.update_capture_progress)
            Clock.unschedule(self.update_eta)
            
            self.ids.progress.value = 60
            self.update_progressbar = False
            self.ids.eta.text = _("Finished!")
            
            logger.debug("Amount of captured data: %s" % pcap_analysis.print_file_size(capture_file_size))
            self.ids.status_update.text = _("Done capturing data. %s captured and stored at %s") % (pcap_analysis.print_file_size(capture_file_size), directory)
            self.ids.finishbutton.disabled = False
            return False
        return True
    
    def change_pcap_names(self):
        """
        Change capture file name from capture.pcap001 to capture001.pcap
        """
        logger.info("Changing captured files' names")
        base_filename = os.path.splitext(os.path.basename(self.filename))[0]
        directory = os.path.dirname(self.filename)
        capture_files = [os.path.join(directory, f) for f in os.listdir(directory) if (os.path.isfile(os.path.join(directory, f)) and base_filename in f)]
        print(capture_files)
        for capture_file in capture_files:
            extra_extension = os.path.splitext(os.path.basename(capture_file))[1].replace(".pcap", "")
            print(extra_extension)
            os.rename(os.path.join(directory, capture_file), os.path.join(directory, base_filename+extra_extension+".pcap"))
            print(os.path.join(directory, base_filename+extra_extension+".pcap"))
    
    
class FinishedScreen(Screen):
    pass


class ReplayScreen(Screen):
    sending = BooleanProperty(False)
    filename = StringProperty("/home/pi/Desktop/test.pcap")
    
    def start_data_sending(self):
        self.sending = not self.sending
        speed = self.ids.send_speed.value
        if self.sending:
            # Send data using configured speed
            print("Sending data from %s with speed: %sMbps" % (self.filename, speed))
            self.handle = Popen("sudo tcpreplay -i eth0 --mbps %s --loop 0 %s" % (speed, self.filename), shell=True, stdout=PIPE, stderr=STDOUT, stdin=PIPE)
            self.ids.send_cancel_button.text = _("Cancel")
        else:
            # Cancel sending data
            print("Stop sending data")
            self.kill_process(self.handle.pid)
            self.ids.send_cancel_button.text = _("Send Data")
    
    def kill_process(self, proc_pid):
        process = psutil.Process(proc_pid)
        for proc in process.children(recursive=True):
            proc.kill()
        process.kill()
        
    def open_popup(self):
        self.popup = LoadFilePopup()
        self.popup.open()
    
    def load_file(self, selection):
        self.filename = selection
        filename = os.path.splitext(os.path.basename(self.filename))[0]
        if len(filename) > 12:
            self.ids.capture_file.text = _("Select pcap file for replay: (%s...)") % (filename[:12])
        else:
            self.ids.capture_file.text = _("Select pcap file for replay: (%s)") % filename
        if self.popup:
            self.popup.dismiss()
        logger.info("File loaded for replay: %s" % self.filename)
        print("loaded file: %s" % self.filename)


class ApplicationChooserScreen(Screen):
    
    def start_app(self, app_name):
        # app_name : screen_name key-value pairs
        app_screens = {"Capture" : "start",
                       "Replay" : "tcp_replay"}
        self.manager.transition.direction = 'left'
        logger.info("Starting app %s" % app_name)
        self.manager.current = app_screens[app_name]


class LanguageChooserScreen(Screen):
    
    def pick_language(self, chosen_language):
        print(chosen_language)
        #language = gettext.translation('cgip_logger', localedir='locale', languages=[chosen_language])
        #language.install()
        
        App.get_running_app().lang = chosen_language
        #App.get_running_app().translation = language.gettext
        
        logger.info("Starting app with language %s" % chosen_language)
        self.manager.transition.direction = 'left'
        self.manager.current = "application_chooser"


class CgipApp(App):
    amount_clicks = NumericProperty(0)
    version = StringProperty(VERSION)
    lang = StringProperty('en')
    translation = ObjectProperty(None, allownone=True)
    
    def __init__(self, **kwargs):
        logger.info("Initializing application...")
        self.switch_lang(self.lang)
        super(CgipApp, self).__init__(**kwargs)
        logger.info("Application initialization done")
    
    def on_lang(self, instance, lang):
        print("changed %s" % lang)
        self.switch_lang(lang)

    def switch_lang(self, lang):
        language = gettext.translation('cgip_logger', localedir='/home/pi/Desktop/cgip_logger/locale/', languages=[self.lang])
        language.install()
        self.translation = language.gettext
        print(self.translation("Finished!"))
    
    def build(self):
        Window.clearcolor = (1, 1, 1, 1)
        #Window.size = (800, 600)
        
        self.language_chooser_screen = LanguageChooserScreen(name='language_chooser')
        self.application_chooser_screen = ApplicationChooserScreen(name='application_chooser')
        ###
        ### Main capturing application
        ###
        self.test_screen = TestScreen(name='test')
        self.start_screen = StartScreen(name='start')
        self.capture_screen = CaptureScreen(name="capture")
        self.finished_screen = FinishedScreen(name="finished")
        ###
        ### Replay pcap file
        ###
        self.replay_screen = ReplayScreen(name="tcp_replay")
        
        self.sm = ScreenManager()
        
        self.sm.add_widget(self.language_chooser_screen)
        self.sm.add_widget(self.application_chooser_screen)
        self.sm.add_widget(self.start_screen)
        self.sm.add_widget(self.test_screen)
        self.sm.add_widget(self.capture_screen)
        self.sm.add_widget(self.finished_screen)
        self.sm.add_widget(self.replay_screen)
        
        return self.sm

    def start_test_capture(self):
        """
        Start test capture for duration in minutes as configured in start screen
        """
        duration_mins = self.start_screen.test_duration_minutes
        logger.info("Start test capture for %s minutes" % duration_mins)
        tcpdump_process, filename = cgip_logger.start_capture(duration_mins/60., "test")
        #print(self.tcpdump_process.pid)
        estimate_duration = 1.2*duration_mins + 0.2
        self.test_screen.actual_capture_duration = self.start_screen.capture_duration_minutes
        self.test_screen.start_capture_progress(tcpdump_process, duration_mins, estimate_duration, filename)
        return
    
    def start_capture(self, local_time):
        """
        Starts main capture for duration in minutes as configured in start screen
        """
        duration_mins = self.start_screen.capture_duration_minutes
        logger.info("Start capture for %s minutes" % duration_mins)
        tcpdump_process, filename = cgip_logger.start_capture(duration_mins/60., local_time)
        self.capture_screen.start_capture_progress(tcpdump_process, duration_mins, filename)

    def check_quit(self):
        self.amount_clicks += 1
        Clock.schedule_once(self.click_timeout, 1)
        if self.amount_clicks > 2:
            logger.info("Quiting application")
            self.stop()
    
    def click_timeout(self, dt):
        self.amount_clicks -= 1

    def shutdown(self):
        logger.info("Shutting down")
        self.stop()
        Popen("sudo shutdown -h now", shell=True, stdout=PIPE, stderr=STDOUT, stdin=PIPE)
    
    def load_file(self, selection):
        """
        Loads file for replay of pcap file
        """
        logger.info("Loading file for tcp replay: %s" % selection[0])
        self.replay_screen.load_file(selection[0])


if __name__ == "__main__":
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    
    # create a file handler
    handler = logging.FileHandler('/home/pi/Desktop/cgip_logger/cgip_logger.log')
    handler.setLevel(logging.DEBUG)
    
    # create a logging format
    formatter = logging.Formatter('[%(asctime)s - %(name)s] : %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    
    # add the handlers to the logger
    logger.addHandler(handler)
    wifi.enable_ethernet()
    CgipApp().run()


## TODO
## '*' means done
#  *Continue from test to actual capture
#  *Design CaptureScreen
#  *Design EndScreen
#  *Test USB stick with capture
#  *Remind user to insert usb stick/Mention device storage left if <40GB
#  *Load program on startup (source kivy/cgip_logger/bin/activate; sudo python Desktop/cgip_logger/main.py)
#  *Test Touchscreen
#  *Documentation (User)
#  *Adjust size popup
#  *Clean up test files
#  *Shutdown RPi on application quit
#  Delete test capture files on test capture cancel
#  *Test data capture max rate
#  Popup when wanting to stop
#  Check what happens when inserting two USB devices
#  *Demo device for data replay
#  Pictures in documentation
#  *Version notice in application
#  *Configure RPi to use RTC
#  *Attach RTC
#  *Attach heatsink
#  Make new images for flags and capture/replay images

# *Add menu to choose application
# *Add extra packet/s information
# *Add language support
# Install tcp replay on all rpi's
# Update Logging to show more info
# Update docs (Installation manual)
# Upload code and docs to sharepoint folder

## Bugs
#  (minor) Application not quiting if capture still running (capture shut down mannually not working)
#  (minor) No mouse when full screen RPi
#  No Data Screen Freezing

## Future Improvements
#  Selectable filters
#  Configuration
#  Add more/better protocol analysis
#  Encrypt PCAP files
#  Send pcap files over sftp to ftp server
#  Software copy protection
#  PCAP file transfer on USB insert?
#  Menu to choose application (Demo or Real)
#  Implement Error Codes for easier support
#  Logging

## Current Features:
#  Monkeyproof
#  CGI Design
#  Touchscreen enabled
#  USB as main output, SD card as backup
#  Update on file size and reminder to use USB
#  Test capture to analyse the data and to give a prognosis on the actual size
#  Plug 'n Play