# -*- coding: utf-8 -*-
"""
Created on Mon Oct 22 10:54:51 2018

@author: jasper.vander.ster
"""

import scapy.all as scapy
import os
import logging

## Logger support
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
    
# create a file handler
handler = logging.FileHandler('cgip_logger.log')
handler.setLevel(logging.DEBUG)

# create a logging format
formatter = logging.Formatter('[%(asctime)s - %(name)s] : %(levelname)s - %(message)s')
handler.setFormatter(formatter)

# add the handlers to the logger
logger.addHandler(handler)

def analyse_pcap(filename):
    """
    Analyzes a sample of the pcap file and returns whether the protocols occur in the file
    
    Input
    -----
        filename: str containing the filepath/name
    
    Output
    ------
        True or False, based on data analysed and protocols provided
        Packets per second
    """
    total_ot_packets = 0
    n_samples = 1000
    i = 0
    time_samples = 1000

    ## Give indication of OT data and an indication of the time (TODO remove when RTC is implemented)
    logger.info("Analyzing samples")
    print("Analyzing samples")
    pcap_file_reader = scapy.PcapReader(filename)
    for pkt in pcap_file_reader:
        print("Analyzing sample %s/%s" % (i+1, n_samples))
        try:
            total_ot_packets += is_ot_data(pkt)
        except:
            pass
#        try:
#            #pkt_time = time.localtime(int(pkt.time))
#            #print(time.strftime('%d%m%Y_%H%M', pkt_time))
#            #times.append(time.strftime('%d%m%Y_%H%M', pkt_time))
#        except:
#            pass
        i += 1
        if i >= n_samples:
            break
    print(total_ot_packets)
    logger.debug("Total OT packets captured: %s" % total_ot_packets)
#    if len(times) > 0:
#        mode_time = max(times, key=times.count)
#    else:
#        mode_time = "CaptureNoTime"

    ## Give indication of packets / second
    try:
        pkt1 = pcap_file_reader.next()
        
        for i in range(time_samples):
            pkt2 = pcap_file_reader.next()
        
        packets_per_second = time_samples/(pkt2.time - pkt1.time)
        print("Packets per second: %s" % packets_per_second)
        logger.debug("Packets per second captured: %s" % packets_per_second)
    except StopIteration:
        print("Not enough packets captured to analyze this feature")
        logger.warning("Not enough packets captured to analyze packets/s")
        packets_per_second = 0
    if i:
        return (float(total_ot_packets)/i, packets_per_second)
    else:
        print("No data found")
        logger.warning("No data found")
        return (-1, 0)

def is_ot_data(packet):
    """
    Determines if packet is ot data based on Destination port
    """
    ot_dports = [2222, 502, 1040, 34980, 5094, 4840, 102] # CIP, modbus, modbus, EtherCAT, Hart, OPC UA, S7COMM
    return (packet.dport in ot_dports)  

def expand(x):
    """
    Expands the protocol list of x
    
    input
    -----
        x: network pakket
        
    output
    ------
        generator object for the protocols used in packet x
    """
    yield x.name
    while x.payload:
        x = x.payload
        yield x.name

def get_file_size(filename):
    """
    Returns file size of filename, in bytes
    """
    return os.path.getsize(filename)

def print_file_size(file_size):
    """
    Returns the file size in a user-friendly way
    """
    if file_size < 1024:
        return "%.0fB" % file_size
    elif file_size < 1024*1024.:
        return "%.0fKB" % (file_size/1024.)
    elif file_size < 1024*1024*1024.:
        return "%.0fMB" % (file_size/(1024*1024.))
    else:
        return "%.1fGB" % (file_size/(1024*1024*1024.))

def estimate_file_size(sample_size, sample_duration, total_duration):
    """
    Returns the estimated file size for the total duration in minuts
    Input and output in minutes/bytes
    """
    return total_duration * (sample_size/sample_duration)


if __name__ == "__main__":
    filename = "C:/Users/jasper.vander.ster/Documents/CGIP Logger/Test Data/ENIPCIP1_20K.pcap"
    file_size = print_file_size(get_file_size(filename))
    print("File size: %s" % file_size)
    analyse_pcap(filename, protocols=["modbus"])
    print("Estimated file size: %s" % print_file_size(estimate_file_size(150000000, 5, 120)))