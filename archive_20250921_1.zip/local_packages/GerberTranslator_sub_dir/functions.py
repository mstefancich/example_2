# let'stry to define a global variable that will locally contain the AM (aperture macros)

AMDict={}

def version(param):
    LogFile.write('03_17_2019')
# Gxx functions

def functionG01(param):
    if verbose:
        LogFile.write("EXECUTED Function G01: set linear interpolation mode\n")
    GS['Interpolation_mode']='linear'

def functionG02(param):
    if verbose:
        LogFile.write("EXECUTED Function G02: set clockwise circular interpolation mode\n")
    GS['Interpolation_mode']='cw'

def functionG03(param):
    if verbose:
        LogFile.write("EXECUTED Function G03: set counterclockwise circular interpolation mode\n")
    GS['Interpolation_mode']='ccw'

def functionG04(param):
    if verbose:
        LogFile.write("EXECUTED Just a comment\n")

def functionG10(param):
    if verbose:
        ErrorFile.write("Function G10: ")
        ErrorFile.write(param)
        ErrorFile.write("\n")

def functionG11(param):
    if verbose:
        ErrorFile.write("Function G11: ")
        ErrorFile.write(param)
        ErrorFile.write("\n")
        

def functionG12(param):
    if verbose:
        ErrorFile.write("Function G12: ")
        ErrorFile.write(param)
        ErrorFile.write("\n")

def functionG36(param):
    if verbose:
        LogFile.write("EXECUTED Polygon Area Fill ON (G36) with index: ")
        LogFile.write(str(GS['Contour_max_index']+1))
        LogFile.write("\n")
    GS['Contour_index']=GS['Contour_max_index']+1
    GS['Contour_sub_index']=0 

def functionG37(param):
    if verbose:
        LogFile.write("EXECUTED Polygon Area Fill OFF (G37) with index: ")
        LogFile.write(str(GS['Contour_index']))
        LogFile.write("\n")
    GS['Contour_max_index']=GS['Contour_index']
    GS['Contour_index']=0
    GS['Contour_sub_index']=0 

def functionG54(testo):
    if verbose:
        LogFile.write("EXECUTED Function G54\n")
    testo=testo.replace('G54D','')
    testo=testo.replace('*','')
    testo=testo.replace('%','')
    GS['Current_aperture']=testo
    return(testo)

def functionG70(param):
    if verbose:
        LogFile.write("EXECUTED Specifies units in INCHes\n")
    GS['Unit']='in'

def functionG71(param):
    if verbose:
        LogFile.write("EXECUTED Specifies units in mm\n")
    GS['Unit']='mm'


def functionG74(param):
    if verbose:
        LogFile.write("EXECUTED Function G74 (single quadrant)\n")
    GS['Quadrant']='single'

def functionG75(param):
    if verbose:
        LogFile.write("EXECUTED Function G75 (multiple quadrant)\n")
    GS['Quadrant']='multiple'

def functionG90(param):
    if verbose:
        LogFile.write("EXECUTED Sets Absolute Cooordinate Format\n")
    GS['Coordinate_mode']='Absolute'

def functionG91(param):
    if verbose:
        LogFile.write("EXECUTED Sets Relative Cooordinate Format\n")
    GS['Coordinate_mode']='Relative'


# %functions

def functionAD(testo):
    testo1=testo
    if verbose:
        LogFile.write("EXECUTED Aperture Define command\n")
    testo=testo[4:len(testo)]
    testo=testo.replace('*','')
    testo=testo.replace('%','')
    for i in range(0,len(testo)):
        if not testo[i].isdigit():
            break
    Aperture_Dcode=testo[0:i]
    testo=testo[i:len(testo)]
    testo=testo.split(',')
    Aperture_type=testo[0]
    testo=testo[1]
    #print("Aperture code and Type: ",Aperture_Dcode,Aperture_type)
    # as of 5 Oct 2020 only Circular (C) and Rectangular (R) are supported
    # we need to add support for Oval (O) and Polygonal (P) apertures.
    # moreover, only solid apertures are supported
    param='ERR'
    if Aperture_type=='C':
        param=testo
    if Aperture_type=='R':
        param=testo.split('X')
        param=(param[0],param[1])
    # adding Oval Support (solid only) on Oct 5th 2020. Unclear how this is
    # used in the rest. Note: it seems to operate correctly
    if Aperture_type=='O':
        param=testo.split('X')
        param=(param[0],param[1])
    if Aperture_type.startswith('FreePoly'): # unsupported aperture
        if verbose:
            LogFile.write("EXECUTED Aperture Define command with Aperture Macro FreePoly\n")
        param=testo.split('X')
        param=tuple(param)  
        #!!! now we need to get the parameters that are stored via the %AMFreePoly0 function in the AMDict
        # this results in the parameters being placed in the Graphical Object
        # this is then plotted in the Plot_Graph_Obj(Gobj) function.
        try:
            param=AMDict[Aperture_type]
        except:
            print("Error, could not find the aperture in the AMDict")
    if Aperture_type.startswith('RoundRect'): # unsupported aperture
        param=testo.split('X')
        param=tuple(param)
        # correctly inserted in GObj but then not supported in Plot_Graph_Obj
        #print("RoundRect param:"+str(param))
        ErrorFile.write("Function AD: Unsupported Aperture type RoundRect\n")
        #print("Function AD: Unsupported Aperture type RoundRect")
        #print("Aperture code and Type: ",Aperture_Dcode,Aperture_type)
        #print("received string: "+testo+"\n")
        # still not supported in the rest of code as of Dec 3rd 2024  
    # now we can update the ApertureFile Dictionary adding (or modifying) the
    # entry associated with the current Aperture_Dcode
    if param=='ERR':
        ErrorFile.write("Function AD: ")
        ErrorFile.write(param)
        ErrorFile.write("\n")
        print("Error in decoding AD command with received text: "+testo)
        print("Aperture code and Type: ",Aperture_Dcode,Aperture_type)
    AP[Aperture_Dcode]=(Aperture_type,param)
    #print(AP)
    
def functionAM(testo):
    if verbose:
        ErrorFile.write("Aperture Macro command: ")
        ErrorFile.write(testo)
        ErrorFile.write("\n")
    # the AM function defining the pattern for FreePoly0 has the following form
    # %AMFreePoly0*
    # 4,1,129,0.800119,0.804999,0.842119,0.803999,0.842356,0.803987,0.884356,0.800987,0.884724,0.800947,0.925724,0.794947,0.925841,0.794929,0.966841,0.787929,0.967185,0.787858,1.008185,0.777858,1.008437,0.777789,1.048437,0.765789,1.048652,0.765719,1.088652,0.751719,1.088940,0.751608,1.126940,0.735608,1.127140,0.735519,1.165140,0.717519,1.165378,0.717399,1.202378,0.697399,
    # 1.202607,0.697266,1.238607,0.675266,1.238883,0.675085,1.272883,0.651085,1.273019,0.650985,1.306019,0.625985,1.306224,0.625821,1.338224,0.598821,1.338416,0.598651,1.369416,0.569651,1.369651,0.569416,1.398651,0.538416,1.398821,0.538224,1.425821,0.506224,1.425985,0.506019,1.450985,0.473019,1.451085,0.472883,1.475085,0.438883,1.475266,0.438607,1.497266,0.402607,
    # 1.497399,0.402378,1.517399,0.365378,1.517519,0.365140,1.535519,0.327140,1.535608,0.326940,1.551608,0.288940,1.551719,0.288652,1.565719,0.248652,1.565789,0.248437,1.577789,0.208437,1.577858,0.208185,1.587858,0.167185,1.587929,0.166841,1.594929,0.125841,1.594947,0.125724,1.600947,0.084724,1.600987,0.084356,1.603987,0.042356,1.603999,0.042119,1.604999,0.000119,
    # 1.604999,-0.000119,1.603999,-0.042119,1.603987,-0.042356,1.600987,-0.084356,1.600947,-0.084724,1.594947,-0.125724,1.594929,-0.125841,1.587929,-0.166841,1.587858,-0.167185,1.577858,-0.208185,1.577789,-0.208437,1.565789,-0.248437,1.565719,-0.248652,1.551719,-0.288652,1.551608,-0.288940,1.535608,-0.326940,1.535519,-0.327140,1.517519,-0.365140,1.517399,-0.365378,1.497399,-0.402378,
    # 1.497266,-0.402607,1.475266,-0.438607,1.475085,-0.438883,1.451085,-0.472883,1.450985,-0.473019,1.425985,-0.506019,1.425821,-0.506224,1.398821,-0.538224,1.398651,-0.538416,1.369651,-0.569416,1.369416,-0.569651,1.338416,-0.598651,1.338224,-0.598821,1.306224,-0.625821,1.306019,-0.625985,1.273019,-0.650985,1.272883,-0.651085,1.238883,-0.675085,1.238607,-0.675266,1.202607,-0.697266,
    # 1.202378,-0.697399,1.165378,-0.717399,1.165140,-0.717519,1.127140,-0.735519,1.126940,-0.735608,1.088940,-0.751608,1.088652,-0.751719,1.048652,-0.765719,1.048437,-0.765789,1.008437,-0.777789,1.008185,-0.777858,0.967185,-0.787858,0.966841,-0.787929,0.925841,-0.794929,0.925724,-0.794947,0.884724,-0.800947,0.884356,-0.800987,0.842356,-0.803987,0.842119,-0.803999,0.800119,-0.804999,
    # 0.800000,-0.805000,-1.600000,-0.805000,-1.603536,-0.803536,-1.605000,-0.800000,-1.605000,0.800000,-1.603536,0.803536,-1.600000,0.805000,0.800000,0.805000,0.800119,0.804999,0.800119,0.804999,$1*%
    #
    # where a single logical line contains everything above after the compacting effect of compact_data_new(..) realized on Dec 3rd 2024
    # we should create some sort of object or variable or something (maybe a dict?) where these AM are stored as a key/value pair where the key is
    # "FreePoly0" and the value is the array/list/tuple of vertexes...
    # this could then be used by the function AP when aprture is FreePoly0 (or the other that have been defined)
    testo=testo.replace('%AM','')
    testo=testo.split('*')
    tt=tuple(testo[1].split(','))
    AMDict[testo[0]]=tt
    #print("Added the following hey entry to AMDict: ",testo[0])
    #print("AMDict: ")
    #print(AMDict)
    # indeed it seems that all the non-standard apertures (FreePoly and RoundedRect) are added to the dict....
    # at this point, the values are not really used by AP....
  
    

def functionAS(testo):
    if verbose:
        LogFile.write("EXECUTED Axis Select command\n")
    testo=testo.replace('%AS','')
    testo=testo.replace('*','')
    testo=testo.replace('%','')
    if testo.startswith('A'):
        GS['Device_A_axis']=testo[1]
        testo=testo[2:len(testo)]
    if testo.startswith('B'):
        GS['Device_B_axis']=testo[1]

def functionOF(testo):
    testo1=['0.0','0.0']
    testo2=['0.0','0.0']
    if verbose:
        LogFile.write("EXECUTED Offset command\n")
    testo=testo.replace('%OF','')
    testo=testo.replace('*','')
    testo=testo.replace('%','')
    if testo.startswith('A'):
        testo=testo.replace('A','')
        testo2=testo.split('B')
        testo1[0]=testo2[0]
        if len(testo2)<2:
            testo1[1]='0.0'
        else:
            testo1[1]=testo2[1]
    if testo.startswith('B'):
        testo=testo.replace('B','')
        testo2=testo.split('A')
        testo1[1]=testo2[0]
        if len(testo2)<2:
            testo1[0]='0.0'
        else:
            testo1[0]=testo2[1]    
    GS['Offset']=(testo1[0],testo1[1])

def functionSF(testo):
    testo1=['1.0','1.0']
    testo2=['1.0','1.0']
    if verbose:
        LogFile.write("EXECUTED Scale Factor command\n")
    testo=testo.replace('%SF','')
    testo=testo.replace('*','')
    testo=testo.replace('%','')
    if testo.startswith('A'):
        testo=testo.replace('A','')
        testo2=testo.split('B')
        testo1[0]=testo2[0]
        if len(testo2)<2:
            testo1[1]='1.0'
        else:
            testo1[1]=testo2[1]
    if testo.startswith('B'):
        testo=testo.replace('B','')
        testo2=testo.split('A')
        testo1[1]=testo2[0]
        if len(testo2)<2:
            testo1[0]='1.0'
        else:
            testo1[0]=testo2[1]    
    GS['Scale_factor']=(testo1[0],testo1[1])

def functionLN(testo):
    if verbose:
        LogFile.write("EXECUTED Layer Name command\n")
    testo=testo.replace('%LN','')
    testo=testo.replace('*','')
    testo=testo.replace('%','')
    GS['Layer_name']=testo

def functionLPD(testo):
    if verbose:
        LogFile.write("EXECUTED Change Polarity to DARK command\n")
        print("EXECUTED Change Polarity to DARK command\n")
    GS['Polarity']='dark'

def functionLPC(testo):
    if verbose:
        LogFile.write("EXECUTED Change Polarity to CLEAR command\n")
        print("EXECUTED Change Polarity to CLEAR command\n")
    GS['Polarity']='clear'
    

def functionFS(param):
    if verbose:
        LogFile.write("EXECUTED Format Setting command\n")
    testo=param.replace('%FSLA','')
    global GS
    GS['Coordinate_format']=(int(testo[1]),int(testo[2]),int(testo[4]),int(testo[5]))

def functionMO(param):
    if verbose:
        LogFile.write("EXECUTED Unit Setting Function\n")
    GS['Unit']=param[3:5]
    

# M02

def functionM02(param):
    if verbose:
        LogFile.write("EXECUTED End of File\n")

# MI[A0..1][B0..1]

def functionMI(param):
    if verbose:
        LogFile.write("EXECUTED MIRROR Setting Function:\n")
    param=param.replace('MI','')
    param=param.replace('*','')
    param=param.replace('%','')
    if param.find("A0")!=-1:
        GS['X_mirror']='False'
        LogFile.write("   DISABLED MIRRORING on A axis\n")
    if param.find("A1")!=-1:
        GS['X_mirror']='True'
        LogFile.write("   ENABLED MIRRORING on A axis\n")
    if param.find("B0")!=-1:
        GS['Y_mirror']='False'
        LogFile.write("   DISABLED MIRRORING on B axis\n")
    if param.find("B1")!=-1:
        GS['Y_mirror']='True'
        LogFile.write("   ENABLED MIRRORING on B axis\n")

# D10..D999 function

def functionD(param):
    if param.startswith('D02'):
        functionD02(param)
        return
    if verbose:
        LogFile.write("EXECUTED Sets Current Aperture or Closes Contour\n")
    param=param.replace('D','')
    param=param.replace('*','')
    param=param.replace('%','')
    if int(param)>=10:
        GS['Current_aperture']=param

# D01, D02, D03 functions

def functionD02(param):
    if GS['Contour_index']>0: #we are in a contour plot
        if verbose:
            LogFile.write("EXECUTED D02 inside contour plot\n")
        GS['Contour_sub_index']=GS['Contour_sub_index']+1
    else:
        if verbose:
            LogFile.write("EXECUTED D02 OUTSIDE contour plot\n")
    functionX(param)
    
def functionX(testo):
    if verbose:
        LogFile.write("EXECUTED Draw command D0?\n")
    #process the X part, the string of the Xvalue is extracted
    if testo.startswith('X'):
        testo=testo.replace('X','')
        for i in range(0,len(testo)):
            if not (testo[i].isdigit() or testo[i]=='-'): # added the '-' control OCT 5 2020
                break
        X_numb=testo[0:i]
        testo=testo[i:len(testo)]
        #print('X_numb ',X_numb)
        #print('testo ',testo)
    else:
        X_numb=''
    #process the Y part, the string of the Yvalue is extracted
    if testo.startswith('Y'):
        testo=testo.replace('Y','')
        for i in range(0,len(testo)):
            if not (testo[i].isdigit() or testo[i]=='-'): # added the '-' control OCT 5 2020
                break
        Y_numb=testo[0:i] # most likely this drops the last valid char OCT 5 2020
        testo=testo[i:len(testo)]
        #print('Y_numb ',Y_numb)
        #print('testo ',testo)
    else:
        Y_numb=''
    #process the I part, the string of the Ivalue is extracted
    if testo.startswith('I'):
        testo=testo.replace('I','')
        for i in range(0,len(testo)):
            if not (testo[i].isdigit() or testo[i]=='.' or testo[i]=='-'): # added '-' OCT 5 2020
                break
        I_numb=testo[0:i]
        testo=testo[i:len(testo)]
    else:
        I_numb='0'
    #process the J part, the string of the Jvalue is extracted
    if testo.startswith('J'):
        testo=testo.replace('J','')
        for i in range(0,len(testo)):
            if not (testo[i].isdigit() or testo[i]=='.' or testo[i]=='-'): # added '-' OCT 5 2020
                break
        J_numb=testo[0:i]
        testo=testo[i:len(testo)]
    else:
        J_numb='0'
    #procedd the D part, the string of the Dvalue is extracted
    command=testo.replace('D','').replace('*','')
    #print('command',command)
    #process the 3 strings to calculate the X and Y coordinate
    if X_numb=='':
        nextX=GS['Current_point'][0]
    else:
        nextX=decode_number(X_numb,GS['Coordinate_format'][1])
    if Y_numb=='':
        nextY=GS['Current_point'][1]
    else:
        nextY=decode_number(Y_numb,GS['Coordinate_format'][3])
    #print(X_numb,Y_numb,I_numb,J_numb,GS['Interpolation_mode']) #debug 27th August

    # if I_numb and J_numb are zero AND the Graphic State interpolation mode
    # is Undefined we should throw an error. We instead force the
    # movement interpolation mode to linear without changing the graphical state
    # Otherwise, we use the Graphic State current interpolation mode
    if (I_numb=='0' and J_numb=='0' and GS['Interpolation_mode']=='Undef'):
        interpolation_mode='linear'
    else:
        interpolation_mode=GS['Interpolation_mode']    
    # we now create a graphical object with the correct parameters
    #print('GS[Current_aperture]', GS['Current_aperture']) # debug 27th August
    cur_ap_code=GS['Current_aperture'] #gets the current aperture from the Graphical State
    
    cur_ap=AP[cur_ap_code] # returns the tuple corresponding to the current aperture
    Gob=GraphicalObjects.GObj(GS['Current_point'],(nextX,nextY),float(I_numb),
                              float(J_numb),interpolation_mode,command,cur_ap,
                              GS['Quadrant'],GS['Contour_index'],
                              GS['Contour_sub_index'],GS['Unit'],GS['Polarity'])
    # and we add it to the list of GraphicalObjects stored in GraphObjList
    global GraphObjList
    GraphObjList.append(Gob)
    # and now we update the position in GraphicalState
    GS['Current_point']=(nextX,nextY)
    return(Gob)
    
# function not found

def functionDefault(param):
    param = param.replace('\n','')
    param = param.replace('\t','')
    response='*** Command not Found: '+param+' ***\n'
    LogFile.write(response)
    
    
def decode_number(s_code,code_format):
    #print(s_code,code_format)
    X=float(int(s_code)/pow(10,int(code_format)))
    return(X)
