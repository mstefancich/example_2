'''
This intends to be a file to be included in another code providing a set of functions
to handle interactions with the display
This library can write also on HDMI display using the standard RGBA format
to do this the 32 bit version of the functions (e.g. clearScreen32() ) can be used
if fbcp is running on the system, the content of fb0 will be copied to fb1 (screen mirroring)
and this will overwrite whoever may have been sent directly to fb1
Color format matching from RGB888 to RGB565 occurrs in this case in fbcp
Sept 10 2025: I had to update the dimension of the numpy elements from 'L' to 'I;16' as,
before updating numpy, L apparently defaulted to 16 bits but after to 8. As I need 16 bits
now this is explicitly stated.
'''
from PIL import Image, ImageFont
import numpy as np
import os

# initialization specific for the display
h, w = 480, 320
fb0 = np.memmap('/dev/fb0', dtype='uint32',mode='w+', shape=(w,h)) # writes on HDMI, uses 32 bit version of functions
fb1 = np.memmap('/dev/fb1', dtype='uint16',mode='w+', shape=(w,h)) # writes on SPI, uses 16 bit version of functions
# fb1 will be overwritten continuously by the content in /dev/fb0 is the fbcp function
# is running in the OS

module_dir = os.path.dirname(__file__)
print("DisplayFunctions dir: ", module_dir)
__DisplayFunctionVersion__='20250910'

def setCursor(state=False):
    if state:
        os.system('setterm -cursor on > /dev/tty0')
    else:
        os.system('setterm -cursor off > /dev/tty0')

def clearScreen(color=0b0000000000011111):
    # clears the screen and sets it to the desired 16 bit color with a default of blue
    # color format is 5-6-5 bits for R-G-B 
    #fb[:]=[0b1111100000000000] # red background
    #fb[:]=[0b0000011111100000] # green background
    #fb[:]=[0b0000000000011111] # blue background
    fb1[:]=[color] 

def clearScreen32(color=0x0000FF):
    # clears the screen and sets it to the desired 16 bit color with a default of blue
    # color format is 8-8-8 bits for R-G-B 
    #fb[:]=[0bFF0000] # red background
    #fb[:]=[0x00FF00] # green background
    #fb[:]=[0x0000FF] # blue background
    fb0[:]=[color] 


def writeText(text="Hallo World",text_color=0b0000011111100000,pos=(100,160),angle=0,dim=32,font='DejaVuSans.ttf'):
    # writes a text in the desired position with a default of 100,160
    # with the indicated color defaulting to green
    # and with a rotation angle (in degrees) of rotation defaulting to 0
    # the text has transparent background
    # alternative fonts are 'JosyWine-G33rg.ttf' or any in ttf format
    font = ImageFont.truetype(os.path.join(module_dir, font), dim) # last number is font size in pixels
    #mask = font.getmask(text, mode='L') # changed to 'I;16' 10 sept 2025 after updating numpy
    mask = font.getmask(text, mode='I;16') 
    #img = Image.new('L', mask.size, color=0) # it is grayscale, color is background from 0 to 255
    img = Image.new('I;16', mask.size, color=0) # it is grayscale, color is background from 0 to 255
    d = Image.core.draw(img.im, 0)
    d.draw_bitmap((0,0), mask, 1) #assigns a value of 1 to the points of the text
    img = img.rotate(angle,expand=True) # we can add a rotation effect if we want...
    
    # now the framebuffer part...
    n = np.array(img) # makes it a 2-dim np.array
    n_h, n_w = min(n.shape,fb1.shape)
    # clipping text region if it falls outside of screen area
#    n_h, n_w = min(n.shape,fb1.shape)
    lim_h,lim_w = fb1.shape
    n_h=min(n_h+pos[0],lim_h)-pos[0]
    n_w=min(n_w+pos[1],lim_w)-pos[1]
    
    inv_n=(1-n)*0b1111111111111111 # needed to clean the fb part where we want our text 
    n=n*text_color # here we set the color to the points of the text that were initially 1

    # now we use a logic AND between fb and inv_n to set to zero the points of fb where
    # we are then going to put our text without modifying the other values (transp background)
    fb1[pos[0]:pos[0]+n_h,pos[1]:pos[1]+n_w] = fb1[pos[0]:pos[0]+n_h,pos[1]:pos[1]+n_w] & inv_n[0:n_h,0:n_w]
    # and finally we place the text at the right position doing actually a logical OR
    # between fb and n. Let's recall that fb, due to the previous AND, has zeros where
    # the pixels of our text are going to be.
    # this approach allows for a transparent text background while maintaining efficiency
    fb1[pos[0]:pos[0]+n_h,pos[1]:pos[1]+n_w] = fb1[pos[0]:pos[0]+n_h,pos[1]:pos[1]+n_w] | n[0:n_h,0:n_w]

    # here the "direct" by pixel apporahc that does the same but at a much slower speed
    # now, in n, we have a 2 dim array containing a number different from zero
    # where we want text_color.
    # we "manually" set the fb points to text_color if the corresponding array value is
    # not null
    # this approach allows to conserve the 
#     for i in range(0,n_h): # runs over each row of n
#         for j in range(0,n_w): # runs over each column of n
#             if(n[i][j]>0):
#                 fb[pos[0]+i,pos[1]+j]=text_color
    #return(n)

def writeText32(text="Hallo World",text_color=0x00FF00, pos=(100,160),angle=0):
    # this version works on /dev/fb0 using 32 bit RGB format
    # it can be used when the fbcp function is operating and it is mirroring
    # /dev/fb0 to /dev/fb1
    # writes a text in the desired position with a default of 100,160
    # with the indicated color defaulting to green
    # and with a rotation angle (in degrees) of rotation defaulting to 0
    # the text has transparent background
    
    font = ImageFont.truetype(os.path.join(module_dir, 'JosyWine-G33rg.ttf'), 40) # last number is font size in pixels
    mask = font.getmask(text, mode='I;16')
    img = Image.new('I;16', mask.size, color=0) # it is grayscale, color is background from 0 to 255
    d = Image.core.draw(img.im, 0)
    d.draw_bitmap((0,0), mask, 1) #assigns a value of 1 to the points of the text
    img = img.rotate(angle,expand=True) # we can add a rotation effect if we want...
    
    # now the framebuffer part...
    n = np.array(img) # makes it a 2-dim np.array
    n_h, n_w = min(n.shape,fb0.shape)
    # clipping text region if it falls outside of screen area
#    n_h, n_w = min(n.shape,fb0.shape)
    lim_h,lim_w = fb0.shape
    n_h=min(n_h+pos[0],lim_h)-pos[0]
    n_w=min(n_w+pos[1],lim_w)-pos[1]
    
    inv_n=(1-n)*0xFFFFFF # needed to clean the fb part where we want our text 
    n=n*text_color # here we set the color to the points of the text that were initially 1

    # now we use a logic AND between fb and inv_n to set to zero the points of fb where
    # we are then going to put our text without modifying the other values (transp background)
    fb0[pos[0]:pos[0]+n_h,pos[1]:pos[1]+n_w] = fb0[pos[0]:pos[0]+n_h,pos[1]:pos[1]+n_w] & inv_n[0:n_h,0:n_w]
    # and finally we place the text at the right position doing actually a logical OR
    # between fb and n. Let's recall that fb, due to the previous AND, has zeros where
    # the pixels of our text are going to be.
    # this approach allows for a transparent text background while maintaining efficiency
    fb0[pos[0]:pos[0]+n_h,pos[1]:pos[1]+n_w] = fb0[pos[0]:pos[0]+n_h,pos[1]:pos[1]+n_w] | n[0:n_h,0:n_w]


def displayImage(img='',angle=0):
    # displays a full screen RGB image rescaling it to full screen
    # allows to specify a rotation angle in degrees (default to zero)
    try:
        img = img.convert('RGB')
    except:
        img = Image.open(os.path.join(module_dir,'cat.bmp'))
        img = img.convert('RGB')
    # rotate if needed
    rotated_img = img.rotate(angle, expand=True)
    # resize to framebuffer size    
    img_resized = rotated_img.resize((h, w), resample=Image.LANCZOS)
    # Convert image to NumPy array
    img_array = np.array(img_resized)
    #print(img_array.shape)
    #return(img_array)
    # now we need to convert each color channel to R5,G6,B5 format
    # Vectorized scaling to RGB565 components
    r5 = (img_array[..., 0] >> 3).astype(np.uint16)  # red → 5 bits
    g6 = (img_array[..., 1] >> 2).astype(np.uint16)  # green → 6 bits
    b5 = (img_array[..., 2] >> 3).astype(np.uint16)  # blue → 5 bits
    # Pack into RGB565 format (16-bit unsigned integer)
    rgb565_array = (r5 << 11) | (g6 << 5) | b5

    # copy in the fb
    fb1[:,:]=rgb565_array
    #return(rgb565_array)

def displayImage32(img='',angle=0):
    # displays a full screen RGB image rescaling it to full screen
    # allows to specify a rotation angle in degrees (default to zero)
    try:
        img = img.convert('RGB')
    except:
        img = Image.open(os.path.join(module_dir,'cat.bmp'))
        img = img.convert('RGB')
    # rotate if needed
    rotated_img = img.rotate(angle, expand=True)
    # resize to framebuffer size    
    img_resized = rotated_img.resize((h, w), resample=Image.LANCZOS)
    # Convert image to NumPy array
    img_array = np.array(img_resized)
    #print(img_array.shape)
    #return(img_array)
    # now we need to convert each color channel to R5,G6,B5 format
    # Vectorized scaling to RGB565 components
    r8 = (img_array[..., 0]).astype(np.uint32)  # red → 8 bits
    g8 = (img_array[..., 1]).astype(np.uint32)  # green → 8 bits
    b8 = (img_array[..., 2]).astype(np.uint32)  # blue → 8 bits
    # Pack into RGB565 format (16-bit unsigned integer)
    rgb888_array = (r8 << 16) | (g8 << 8) | b8

    # copy in the fb
    fb0[:,:]=rgb888_array
    #return(rgb565_array)


def displayRectangle(pos=(20,20),size=(100,200),color=0b0000011111100000):
    # displays a full color rectangle with the top left vertex in pos=(X,Y)
    # size=(X_size,Ysize) and color=color
    # the first value(s) are for the vertical axis oriented downward
    # clipping rectangle if it falls outside of screen area
    lim_h,lim_w = fb1.shape
    n_h=min(size[0]+pos[0],lim_h)-pos[0]
    n_w=min(size[1]+pos[1],lim_w)-pos[1]

    fb1[pos[0]:pos[0]+n_h,pos[1]:pos[1]+n_w]=color

def displayRectangle32(pos=(20,20),size=(100,200),color=0x00FF00):
    # displays a full color rectangle with the top left vertex in pos=(X,Y)
    # size=(X_size,Ysize) and color=color
    # the first value(s) are for the vertical axis oriented downward
    # clipping rectangle if it falls outside of screen area
    lim_h,lim_w = fb0.shape
    n_h=min(size[0]+pos[0],lim_h)-pos[0]
    n_w=min(size[1]+pos[1],lim_w)-pos[1]

    fb0[pos[0]:pos[0]+n_h,pos[1]:pos[1]+n_w]=color

# test functions
def test():
    clearScreen(0b1000010000010000) # gray background
    #clearScreen(0b0) # black background
#     res=writeText()
#     res=writeText("ancora",0b1111100000011111,(150,220),20)
#     res=writeText("una Linea",0b1111100000000000,(250,100))
#     writeText("ciao!",0b0000011111111111,(230,100),-10)
    try:
        #img = Image.open('athena_1.bmp')
        img = Image.open('cat.bmp')
    except:
        print("Cant' open image")
        exit(0)
    displayImage(img,0)
    res=writeText("Ciao!",0b1111100000000000,(100,90))
    setCursor(False)


if __name__ == "__main__":
    # Code here runs only when the script is executed directly
    test()
