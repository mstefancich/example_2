import pickle

class GObj:
    def __init__(self,start,end,I,J,interpolation,command,aperture,
                 quadrant_mode,Contour_index='0',Contour_sub_index='0',
                 unit='in',polarity='dark'):
        self.start=start # start point of interpolation
        self.end=end #end point of interpolation
        self.I=I #X-offset of arc center with respect to start point (for Circ interp)
        self.J=J #Y-offset of arc center with respect to start point (for Circ interp)
        self.interpolation=interpolation # interplatio mode: linear, Clockwise Cir, CounterClockwise Circ
        self.command=command # draw (01) move (02) or flash (03) action
        self.aperture=aperture # aperture data ('c'+radius or 'r'+x and Y size or 'o'+x and y axis)
        self.quadrant_mode=quadrant_mode # single or multiple quadrant for circular interpolation
        self.Contour_index=Contour_index # contour index if the object belongs to a contour plot
        self.Contour_sub_index=Contour_sub_index # contour sub-index if the object belongs to a contour ploe
        self.unit=unit
        self.polarity=polarity
    
    def print(self):
        print(self.start,self.end,self.interpolation,self.command,
              self.aperture,self.Contour_index,self.Contour_sub_index,self.unit)
        
#     def save(self,OpenFile):
#         data=(self.start,self.end,self.I,self.J,self.interpolation,self.command,
#               self.aperture,self.quadrant_mode,self.Contour_index,self.Contour_sub_index)
#         for dt in data:
#             OpenFile.write(str(dt))
#             OpenFile.write('\t')
#         OpenFile.write('\n')
    def save(self,OpenFile):
        pickle.dump(self, OpenFile)
 

